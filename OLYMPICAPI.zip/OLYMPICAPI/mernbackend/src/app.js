const express = require("express");
const app = express();
const path = require("path");
const hbs = require("hbs");

//email verifiation
// const Token=require("./models/token");
// const sendEmail=require("./utils/sendEmail");
// const crypto=require("crypto");


//email verification
//const nodemailer=require("nodemailer")

//for send mail
// const sendVerifyMail=async(username,email)=>{
//   try{
//     nodemailer.createTransport({
//       host:'akshitamukati20654@acropolis.in'
//       port: 587
//     })

//   }catch(error){
//     console.log(error.message);
//   }
// }


require("./db/conn");
const Register = require("./models/registerss");
const add_pets = require("./models/add_pets");
const { reverse } = require("dns");

const port = process.env.PORT || 3000
const static_path = path.join(__dirname,"../public");
const template_path = path.join(__dirname,"../templates/views");
const partials_path = path.join(__dirname,"../templates/partials");

app.use(express.json());
app.use(express.urlencoded({extended:false}));

app.use(express.static(static_path));

app.set("view engine" ,"hbs");
app.set("views" ,template_path);
hbs.registerPartials(partials_path);
app.get("/", async(req, res) => {
  const   dataOfPets = await add_pets.find();
  res.status(201).render("index", {dataOfPets:dataOfPets});
});
app.get("/login", (req, res) => {
  res.render("login");
});
app.get("/ALindex", async (req, res) => {
  const   dataOfPets = await add_pets.find();
  res.status(201).render("ALindex", {dataOfPets:dataOfPets});
});
app.get("/index", (req, res) => {
  const   dataOfPets = add_pets.find();
  res.status(201).render("index", {dataOfPets:dataOfPets});
});
app.get("/add_pets", (req, res) => {
  res.render("add_pets");
});
app.get("/cats", async(req, res) => {
  const dataOfPets = await add_pets.find();
  res.status(201).render("cats", {dataOfPets:dataOfPets});
});
app.get("/dogs", async(req, res) => {
  const dataOfPets = await add_pets.find();
  res.status(201).render("dogs", {dataOfPets:dataOfPets});
});
app.get("/register", (req, res) => {
  res.render("register");
});

app.post("/register", async(req,res)=>{
  try{
      const password=req.body.password;
      const cpassword=req.body.confirmpassword;
      
      if(password===cpassword){
          const registerEmployee =new Register({
            email:req.body.email,
            username:req.body.username,
              password:password,
              confirmpassword:cpassword 
          })
          

          const registered= await registerEmployee.save();
          
          
          
          res.render("ALindex");
      }else{
          res.send("Password not Matching!");
      }
  }catch(error){
      res.status(400).send(error);
  }
});

app.post("/login",async(req,res)=>{
  try {
    const username=req.body.username;
    const password=req.body.password;

    const usernamekavariable = await Register.findOne({username:username});

    if(usernamekavariable.password===password)
    {
      // res.status(201).render("ALindex");
      const   dataOfPets = await add_pets.find();
      res.redirect("/ALindex");
    }
    else
    {
      // res.send("Invalid login credentials!!");
      // alert("Invalid login cresdentiald!!!");
      document.write("In");
    }
  } catch (error) {
    res.status(400).send(error);
  }
})

app.post("/add_pets",async(req,res)=>{
  try {
    const add_petss =new add_pets({
      username:req.body.username,
      phone:req.body.phone,
      petname:req.body.petname,
      petage:req.body.petage,
      breed:req.body.breed,
      pettype:req.body.pettype,
      image:req.body.image,
      pettype__:req.body.pettype__,
    })
    
    // const tempu=req.body.username;
    // res.status(201).render("ALindex");
    // const dataOfPets = await add_pets.findOne({username:tempu});
    const add_petswalatempvariable= await add_petss.save();
    const   dataOfPets = await add_pets.find();
      res.redirect("/ALindex");
      // res.redirect('/login');
      // window.location.href = "http://localhost:3000/login";
  } catch (error) {
    res.status(400).send(error);
  }
})

app.listen(port, () => {
    console.log("Hello from childrens");
});