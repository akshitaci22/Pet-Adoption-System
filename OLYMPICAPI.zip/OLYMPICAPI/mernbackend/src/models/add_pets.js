const mongoose=require("mongoose");

const add_pets_schema_1O1=new mongoose.Schema({
    username: {
        type:String,
        required:true,
    },
    phone: {
        type:Number,
        required:true
    },
    petname: {
        type:String,
        required:true,
    },
    petage: {
        type:Number,
        required:true
    },
    breed: {
        type:String,
        required:true
    },
    type:
    {
        type:String,
        required:true
    },
    image : { 
        data: Buffer, contentType: String 
    },
    pettype__: {
        type:String,
        required:true
    },
})

const Add_petscollection = new mongoose.model("Addpet",add_pets_schema_1O1);

module.exports = Add_petscollection;